﻿using SampleProject.BLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SampleProject.DLL
{
    public class DBFunction
    {
        string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        /// <summary>
        /// Fetching all employees
        /// </summary>
        /// <param name="sqlCmd"></param>
        /// <returns></returns>
        public DataTable GetEmployeeData(SqlCommand sqlCmd)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                sqlCmd.Connection = con;
                using (SqlDataAdapter sda = new SqlDataAdapter(sqlCmd))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        /// <summary>
        /// Common method which executes after Insert, Update and Delete
        /// </summary>
        /// <param name="sqlCmd"></param>
        /// <returns></returns>
        public bool InsertUpdateDeleteEmployee(SqlCommand sqlCmd)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                sqlCmd.Connection = con;
                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            return result > 0;
        }

        /// <summary>
        /// Get List of all Employees if search param is empty 
        /// Otherwise fetch only matched rows from phone and lastName column
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public DataTable GetEmployees(string search)
        {
            string query = "SELECT * FROM Employees";

            SqlCommand sqlCmd = new SqlCommand();
            if (!String.IsNullOrEmpty(search))
            {
                query += " WHERE LastName LIKE '%'+ @LastName +'%' or Phone LIKE '%'+ @Phone +'%' ";
                sqlCmd.Parameters.AddWithValue("@LastName", search);
                sqlCmd.Parameters.AddWithValue("@Phone", search);

            }
            query += "  ORDER BY HireDate";
            sqlCmd.CommandText = query;
            return this.GetEmployeeData(sqlCmd);

        }

        /// <summary>
        /// Add Employee
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="phone"></param>
        /// <param name="zip"></param>
        /// <param name="hireDate"></param>
        /// <returns></returns>
        public bool InsertEmployee(string firstName, string lastName, string phone, string zip, DateTime? hireDate)
        {
            string query = "INSERT INTO Employees VALUES(@FirstName, @LastName, @Phone, @Zip, @HireDate)";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@FirstName", firstName);
                cmd.Parameters.AddWithValue("@LastName", lastName);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@zip", zip);
                cmd.Parameters.AddWithValue("@HireDate", hireDate==null?(object)DBNull.Value: hireDate.Value);
                return this.InsertUpdateDeleteEmployee(cmd);

            }

        }
        /// <summary>
        /// Update Employee with id for updated parameters
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="phone"></param>
        /// <param name="zip"></param>
        /// <param name="hireDate"></param>
        /// <returns></returns>
        public bool UpdateEmployee(int Id, string firstName, string lastName, string phone, string zip, DateTime? hireDate)
        {
            string query = "UPDATE Employees SET FirstName=@FirstName, LastName=@LastName, Phone=@Phone,zip=@zip, HireDate= @HireDate  WHERE ID=@ID";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@ID", Id);
                cmd.Parameters.AddWithValue("@FirstName", firstName);
                cmd.Parameters.AddWithValue("@LastName", lastName);
                cmd.Parameters.AddWithValue("@Phone", phone);
                cmd.Parameters.AddWithValue("@zip", zip);
                cmd.Parameters.AddWithValue("@HireDate", hireDate == null ? (object)DBNull.Value : hireDate.Value);
                return this.InsertUpdateDeleteEmployee(cmd);

            }

        }

        /// <summary>
        /// Delete Employee with id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public bool DeleteEmployee(int Id)
        {
            string query = "DELETE FROM Employees WHERE ID=@ID";
            using (SqlCommand cmd = new SqlCommand(query))
            {
                cmd.Parameters.AddWithValue("@ID", Id);
                return this.InsertUpdateDeleteEmployee(cmd);

            }

        }
    }
}