﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using SampleProject.BLL;

namespace SampleProject
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGrid();
            }
            txtSearch.Attributes.Add("placeholder","Enter Last Name or Phone");
            txtSearch.Attributes.Add("type", "search");
        }

        private void BindGrid()
        {
            
            grdEmployees.DataSource = Employee.GetEmployees(txtSearch.Text);
            grdEmployees.DataBind();
        }

        protected void Insert(object sender, EventArgs e)
        {
            string firstName = txtNFirstName.Text;
            string lastName = txtNLastName.Text;
            string phone = txtNPhone.Text;
            string zip = txtNZip.Text;
            DateTime? hireDate;
            DateTime date;

            //Handling hiredate
            hireDate = DateTime.TryParse(dpNHireDate.Text, out date)?date:(DateTime?)null;
             
            Employee.InsertEmployee(firstName, lastName, phone, zip, hireDate);

            clearControls();
            this.BindGrid();
        }
        private void clearControls() {
           txtNFirstName.Text=string.Empty;
            txtNLastName.Text = string.Empty;
            txtNPhone.Text = string.Empty;
            txtNZip.Text = string.Empty;
            dpNHireDate.Text = string.Empty;
        }
        protected void OnRowEditing(object sender, GridViewEditEventArgs e)
        {
            grdEmployees.EditIndex = e.NewEditIndex;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "script", "initDataPicker();initMask();", true);
            this.BindGrid();
        }

        protected void OnRowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            
            GridViewRow row = grdEmployees.Rows[e.RowIndex];
            int employeeId = Convert.ToInt32(grdEmployees.DataKeys[e.RowIndex].Values[0]);
            string firstName = (row.FindControl("txtFirstName") as TextBox).Text;
            string lastName = (row.FindControl("txtLastName") as TextBox).Text;
            string phone = (row.FindControl("txtPhone") as TextBox).Text;
            string zip = (row.FindControl("txtZip") as TextBox).Text;
            DateTime? hireDate;
            DateTime date;
            hireDate = DateTime.TryParse((row.FindControl("txtHireDate") as TextBox).Text, out date) ? date : (DateTime?)null;
            Employee.UpdateEmployee(employeeId, firstName, lastName, phone, zip, hireDate);

            grdEmployees.EditIndex = -1;
            this.BindGrid();
        }

        protected void OnRowCancelingEdit(object sender, EventArgs e)
        {
            grdEmployees.EditIndex = -1;
            this.BindGrid();
        }

        protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int employeeId = Convert.ToInt32(grdEmployees.DataKeys[e.RowIndex].Values[0]);

            Employee.DeleteEmployee(employeeId);

            this.BindGrid();
        }

        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != grdEmployees.EditIndex)
            {
                (e.Row.Cells[6].Controls[2] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this employee?');";
            }
        }

        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            grdEmployees.PageIndex = e.NewPageIndex;
            this.BindGrid();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.BindGrid();
        }

        protected void btnClearSearch_Click(object sender, EventArgs e)
        {
            txtSearch.Text = String.Empty;
            this.BindGrid();
        }
    }
}