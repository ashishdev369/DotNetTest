﻿using SampleProject.DLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace SampleProject.BLL
{
    public class Employee : IDisposable
    {
        public static DataTable GetEmployees(string search) {
            return new DBFunction().GetEmployees(search);
        }

        public static bool InsertEmployee(string firstName, string lastName, string phone, string zip, DateTime? hireDate)
        {
            return new DBFunction().InsertEmployee(firstName, lastName, phone, zip, hireDate);
        }

        public static bool UpdateEmployee(int Id, string firstName, string lastName, string phone, string zip, DateTime? hireDate)
        {
            return new DBFunction().UpdateEmployee(Id, firstName, lastName, phone, zip, hireDate);
        }

        public static bool DeleteEmployee(int Id)
        {
            return new DBFunction().DeleteEmployee(Id);
        }

        public void Dispose()
        {
            this.Dispose();
        }
    }
}